package com.irctc.trainmain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainTicketReservationApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainTicketReservationApplication.class, args);
	}
}
